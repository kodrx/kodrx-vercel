# KodRx App

Aplicación web de recetas médicas digitales para médicos, farmacias y laboratorios.

## Módulos principales:
- Médico
- Farmacia
- Laboratorio

Proyecto en desarrollo con despliegue en Vercel.
